

var EventEmitter = require('events')

var emitter = new EventEmitter()

function spraywater()
{
    console.log('spray water.....');
   
}

function extingusher()
{
    console.log('fire extengusher')
}
emitter.on("fire" , spraywater)

emitter.addListener("spray",extingusher)

emitter.emit("fire")

emitter.emit("spray")
// emitter.on('call a Listener' ,()=>{
//     console.log('Listener is called ........1')
// })
// emitter.on('call a Listener' ,()=>{
//     console.log('Listener is called ........2')
// })
// emitter.on('call a Listener' ,()=>{
//     console.log('Listener is called ........3')
// })


// emitter.emit('call a Listener')

