var express=require('express')



var app=express()



app.get('/',(req,res)=>{

  res.send('<h1 style="color:red:text-align:center">hi this is get method in express</h1>')

})
//app.get('/name',(req,res)=>{

    //res.send('<h1 style="color:red:text-align:center">hi this is inside /name </h1>')

  //})

//app.get('/name/:id',(req,res)=>{

      //var id=req.params.id;
      app.get('/name',(req,res)=>{

        var id=req.query.id;
      var name;

      if(id==1){

          name="waqeer"

      }



      else if(id==2){

          name="rakeh"

      }

      else if(id==3){

        name="syed"

    }



      else{

          name="deepu"

      }



    res.send(`<h1>hi welcome ${name} and ur id is ${id}</h1>`)

  })  



app.listen(8080,(req,res)=>{

  console.log('server created')



})