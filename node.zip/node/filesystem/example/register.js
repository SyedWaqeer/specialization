var express=require('express')

var app=express();

app.get('/sub',(req,res)=>{
    var name=req.query.name;
    var age=req.query.age;
    res.send(`<h1>Hai welcome ${name} and age is ${age}</h1>`)
})

app.listen(8088,()=>{
    console.log('server is running')
})