var http=require('http')
var fs=require('fs')
http.createServer((req,res)=>{
    res.write('<h1>hello welcome...</h1>')
    fs.readFile('abc.txt','utf-8',function(err,data){
        res.write(data)
        res.end()
    })
}).listen(4201,(req,res)=>
    {
    console.log('running...........')
    })
//npm i nodemon
//node (java script file
fs.readFile('abc.txt','utf-8',function(err,data){
    console.log(data)
})

fs.writeFile('file1.js',"console.log('dfff')",function(err){
    console.log('file created')
})
fs.appendFile('abc.txt',"console.log('dfff')",function(err){
    console.log('file created')
})
fs.appendFile('xyz.txt',"console.log('dfff')",function(err){
    console.log('file created')
})
fs.unlink('abc.txt',(err)=>{
    console.log(err)
})