var calc =require('./calculator'
)
var result=calc.add(10,10)
console.log(`adittion ${result}`);

var res=calc.sub(20,10)
console.log(`substraction ${res}`);



