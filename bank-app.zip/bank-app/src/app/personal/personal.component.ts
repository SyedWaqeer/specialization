import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal',
  templateUrl: './personal.component.html',
  styleUrls: ['./personal.component.css']
})
export class PersonalComponent implements OnInit {
  val: any;
  val1: any;
  constructor() { }

  ngOnInit(): void {
  }
  demo(v:any, v1:any){
    this.val=(v*v1*0.07);
  }

  demo1(v:any, v1:any){
    this.val1=(v*v1*0.04);
  }

}
